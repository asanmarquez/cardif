package mx.com.bnpparibas.cardif.message;

import static java.lang.Math.abs;
import static java.lang.Math.min;
import static java.lang.Math.pow;
import static java.lang.Math.random;
import static java.lang.Math.round;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.codec.DecoderException;
import org.bouncycastle.util.encoders.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


import mx.com.bnparibas.cardif.message.exception.MessageWrappedException;
import mx.com.bnpparibas.cardif.message.dto.ObjectRequest;
import mx.com.bnpparibas.cardif.message.helper.AESEncryption;
import mx.com.bnpparibas.cardif.message.helper.GlobalMessageAdapter;
import mx.com.bnpparibas.cardif.message.helper.PropertiesFile;
import mx.com.bnpparibas.cardif.message.validation.ValidaObject;

/***********************************************************************************************
 *                                ID:MEX0151 POSNET E-LAM                                       *
 *  *********************************************************************************************
 *   Fecha: 24/01/2018                                                                          *
 *   Descripci�n:Clase que genera el cifrado y descifrado del servicio del bus externo	       *
 *   @author: Floricelda Cabrera Santos                                                         *
 * **********************************************************************************************/
public class MessageWrapped {
	/**
	 * @param String xmlRequest
	 * @return String mensajeCifrado
	 */
	public synchronized String cifrarMensaje(ObjectRequest objectRequest)throws MessageWrappedException{
		PropertiesFile propertiesFile= new PropertiesFile();
		String pathPrincipal = propertiesFile.getProperties().getProperty(propertiesFile.getPathXmlPrincipales());
		Date dateRequest = new Date();
		Integer test = (int) (Math.random() * 3) + 1;
		Long timeRequest = dateRequest.getTime()+test;
		final String fileGlobalMessage = pathPrincipal+"globalMessageRequest"+timeRequest+".xml";
		final String fileMessageWrapped = pathPrincipal+"messageWrappedRequest.xml";

		String mensajeCifrado="";
		String globalMessageCifradoEnAes="";
		//Se valida que el objeto objectRequest contenga valores para realizar el cifrado.
		if(new ValidaObject().validaObjetoNoVacio(objectRequest).booleanValue()==true){

			//1. Cifrar el xmlRequest a base64

			try {
				String xmlRequestCodificado = new String(Base64.encode(objectRequest.getMsgItemXml().getBytes("UTF-8")));
				objectRequest.setMsgItemXml(xmlRequestCodificado);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			GlobalMessageAdapter globalMessageAdapter= new GlobalMessageAdapter();
			//2. Agregar el xmlRequest en el msgItem del GlobalMessaje y dem�s par�metros din�micos
			Boolean respuestaglobalMessageAdapter=false;
			try {
				respuestaglobalMessageAdapter = globalMessageAdapter.generarGlobalMessage(objectRequest,timeRequest);

			} catch (XPathExpressionException | SAXException | IOException
					| ParserConfigurationException
					| TransformerFactoryConfigurationError
					| TransformerException e2) {
				e2.printStackTrace();
			}

			//3. Cifrar el globalMessage a AES128
			AESEncryption aESEncryption= new AESEncryption();
			try {
				if(respuestaglobalMessageAdapter.booleanValue()==true)
					globalMessageCifradoEnAes = aESEncryption.encrypt(muestraContenido(fileGlobalMessage), objectRequest.getKeyChiperedAES());

			} catch (InvalidKeyException | NoSuchAlgorithmException
					| NoSuchPaddingException | IllegalBlockSizeException
					| BadPaddingException | IOException | DecoderException e1) {
				e1.printStackTrace();
			}

		}else{
			mensajeCifrado="Setee con alg�n valor todos los atributos de ObjectRequest, ya que todos son requeridos.";	
		}
		return globalMessageCifradoEnAes;
	}


	/**
	 * @param String mensajeCifrado
	 * @return String xmlRespuestaBus
	 * @throws IOException 
	 * @throws ParserConfigurationException 
	 * @throws SAXException 
	 * @throws XPathExpressionException 
	 */
	public synchronized String desCifrarMensaje(String mensajeCifrado, String key) throws MessageWrappedException,IOException, SAXException, ParserConfigurationException, XPathExpressionException{
		PropertiesFile propertiesFile= new PropertiesFile();
		String pathPrincipal = propertiesFile.getProperties().getProperty(propertiesFile.getPathXmlPrincipales());

		String xmlRespuestaBus= "";
		String msgItemDescifrada="";
		Date dateRequest = new Date();
		Integer test = (int) (Math.random() * 3) + 1;
		Long timeResponse = dateRequest.getTime()+test;
		String file= pathPrincipal+"globalMessageResponse"+timeResponse+".xml";
		
		//1. Descifrar MessageWrapped AES128
		AESEncryption aESEncryption= new AESEncryption();
		try {
			xmlRespuestaBus = aESEncryption.decrypt(mensajeCifrado, key);
			File globalRequestResponse= new File(file);
			Boolean fileCreate = globalRequestResponse.createNewFile();
			System.out.println("--> Path GlobalMessageResponse: "+file);
			System.out.println("--> Respuesta Bus: "+fileCreate);
			BufferedWriter bw = new BufferedWriter(new FileWriter(globalRequestResponse));
			bw.write(xmlRespuestaBus);
			bw.close();

			Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(file));
			XPath xpath = XPathFactory.newInstance().newXPath();

			//Se obtiene el mensaje de MsgItem
			NodeList msgItemResponse = (NodeList)xpath.evaluate("//Response//MsgItem", doc, XPathConstants.NODESET);
			msgItemDescifrada = getTexto(msgItemResponse.item(0));
           //Se decodifica el mensaje y se regresa el MsgItem
			return  new String(Base64.decode(msgItemDescifrada.getBytes()),"UTF-8");
		} catch (InvalidKeyException | IllegalBlockSizeException
				| BadPaddingException | UnsupportedEncodingException
				| NoSuchAlgorithmException | NoSuchPaddingException
				| InvalidAlgorithmParameterException | DecoderException e) {
			e.printStackTrace();
		}
		return msgItemDescifrada;
	}
	
	/**
     * Devuelve el texto de un nodo: <tag>TEXTO</tag>
     * @param n
     * @return
     */
    public static String getTexto (Node n) {
        NodeList nl = n.getChildNodes();
        Node act=null;
        for (int i=0; i < nl.getLength(); i++) {
            act = nl.item(i);
            if (act == null) return null;
            if ((act.getNodeType() == Node.CDATA_SECTION_NODE)||(act.getNodeType() == Node.TEXT_NODE)) return act.getNodeValue();
        }
        return "";
      }
    


	/**
	 * @param File file
	 * @param Charset charset
	 * @return String
	 * @throws IOException
	 */
	public synchronized String readFile(File file, Charset charset) throws IOException {
		return new String(Files.readAllBytes(file.toPath()), charset);
	}
	
	public synchronized String muestraContenido(String archivo) throws FileNotFoundException, IOException {
		String cadena;
		String cadenaReturn="";

		File f = new File(archivo);
		BufferedReader b = new BufferedReader(
				   new InputStreamReader(
		                      new FileInputStream(f), "UTF-8"));
		while((cadena = b.readLine())!=null) {
			cadenaReturn= cadenaReturn+cadena;
		}
		b.close();

		return cadenaReturn;
	}


}
