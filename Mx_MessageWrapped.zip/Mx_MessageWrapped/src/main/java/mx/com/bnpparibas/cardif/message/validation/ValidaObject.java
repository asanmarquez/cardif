package mx.com.bnpparibas.cardif.message.validation;

import java.lang.reflect.Field;
/************************************************************************************************
 *                                ID:MEX0151 POSNET E-LAM                                       *
 *  *********************************************************************************************
 *   Fecha: 30/01/2018                                                                          *
 *   Descripci�n:Clase que realiza la validaci�n de campos vac�os del request       	        *
 *   @author: Floricelda Cabrera Santos                                                         *
 * **********************************************************************************************/
public class ValidaObject {
	
public Boolean validaObjetoNoVacio(Object objeto){
	Boolean resultado = true;
	Field[] arrayAntes=objeto.getClass().getDeclaredFields();
	if(arrayAntes != null && arrayAntes.length>0){
		for(Field obj:arrayAntes){
			if(obj == null || obj.toString().isEmpty())
				resultado =false;
		}
	}
	return resultado;
}
}
