package mx.com.bnpparibas.cardif.message;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.naming.NamingException;
import javax.xml.namespace.QName;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.xpath.XPathExpressionException;

import mx.com.bnpparibas.cardif.message.dto.ObjectRequest;
import mx.com.bnpparibas.cardif.message.helper.AESEncryption;

import org.apache.commons.codec.DecoderException;
import org.xml.sax.SAXException;

import com.bnpparibas.cardif.mx.schema.authentication.v1.LoginRequest;
import com.bnpparibas.cardif.mx.schema.authentication.v1.LoginResponse;
import com.bnpparibas.cardif.mx.schema.facade.ServiceServiceagent;
import com.bnpparibas.cardif.mx.schema.wrapped_message.v1.MessageWrapped;

public class Pruebas {
	static ServiceServiceagent serviceServiceagent=null;
	
	public static void main(String[] s) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException, NamingException {
		 serviceServiceagent= new ServiceServiceagent(
					//LA IP DEL WSDL FAVOR DE DEJARLO DIN�MICA O CONFIGURABLE
					new URL("http://172.17.186.152:7790/Services/Service.serviceagent?wsdl"), //URL BUS INTERNO DEV 
//					new URL("http://172.17.186.58:7790/Services/Service.serviceagent?wsdl"), //URL BUS INTERNO Z 
					new QName("http://cardif.bnpparibas.com/mx/schema/facade", "Service.serviceagent")
					);
//		 LoginRequest login = new LoginRequest();
//			login.setApplicationId("SESAME");
//			login.setLogin("APP_MX_CertificadoFIU");
//			login.setPassword("P@ss_61977");
//			
//			LoginResponse response= serviceServiceagent.getPortTypeEndpoint().login(login);
//           System.out.println("Token: "+response.getToken());
//		for(int x=0; x<1;x++){
//			System.out.println("Iniciando petici�n..."+ new Date());
//			time_start = (double) System.currentTimeMillis();
			
       /**********************SERVICIOS SAC*******************************/
//			pruebaclaimsPrincipal("2c671c6f1ae0c802f9a6003d943eaba60230210e"); //claims OK
//			pruebaclaimsDetalle("b1c275e654d51813b1eedacea5d34fc1a0696f34");//Claims detail  OK
//			pruebaSuscriptionList("20669ce265708858a8715c993b4f0fb03ec52d6b");//ListaEmision   OK
//			pruebaSuscriptionDetalle("20669ce265708858a8715c993b4f0fb03ec52d6b");//DetalleEmisi�n   OK
//			pruebaCollectionList("20669ce265708858a8715c993b4f0fb03ec52d6b");//ListaCobranza    OK
//			pruebaCollectionDetalle("eb6a5641f0e353cf3472807a3aef75fbe18276f7");//DetalleCobranza OK
	/**********************SERVICIOS POSNET FIU*******************************/
			saveVenta("6533232c65d46beb0032a9cd30a54004e2988986");	 //VentaPosnet
		 //ReadTransactionIsPaid("3f800f87115c076e68ac7161405df891bd8e5971");
//			validTransaction("2a8869070bf98056cebe694db9257832e0488429"); //PayOnline
//			validTransactionIsPaid("2a8869070bf98056cebe694db9257832e0488429");
			//saveTransaction("b6693ae3569bc53f43f3480b71c1735399893b25");
			//285	Reportes::GetCertified
			//286	PayOnline::DoTransaction
			//getCertified("6533232c65d46beb0032a9cd30a54004e2988986");
//			doTransaction("a118f181de98fcee8536decfc062d2c9822dddba");
//			
//			AESEncryption aESEncryption= new AESEncryption();
//			String fff;
//			try {
//				fff = aESEncryption.decrypt("PGdldENlcnRpZmljYWRvUmVzcG9uc2UgeG1sbnM6U09BUC1FTlY9Imh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3NvYXAvZW52ZWxvcGUvIiB4bWxuczpuczE9Imh0dHA6Ly93cy5zZWxsZXIudmVudGFzLmNvcmUucG9zbmV0LmNhcmRpZi5jb20ubXgvIiB4bWxuczpzb2FwPSJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy9zb2FwL2VudmVsb3BlLyI+PHJldHVybiB4bWxuczpuczI9Imh0dHA6Ly9jYXJkaWYuYm5wcGFyaWJhcy5jb20vbGFtL3NjaGVtYS9jb21tb24vdjEuMSIgeG1sbnM6bnM0PSJodHRwOi8vY2FyZGlmLmJucHBhcmliYXMuY29tL2xhbS9zY2hlbWEvcGVyc29uL3YxLjEiIHhtbG5zOm5zMz0iaHR0cDovL2NhcmRpZi5ibnBwYXJpYmFzLmNvbS9sYW0vc2NoZW1hL3NlbGwvdjEuMSIgeG1sbnM6bnM1PSJodHRwOi8vY2FyZGlmLmJucHBhcmliYXMuY29tL2xhbS9zY2hlbWEvYWRkcmVzcy92MS4xIiB4bWxuczpuczY9Imh0dHA6Ly9jYXJkaWYuYm5wcGFyaWJhcy5jb20vbGFtL3NjaGVtYS9wYXltZW50L3YxIiB4bWxuczpuczc9Imh0dHA6Ly9jYXJkaWYuYm5wcGFyaWJhcy5jb20vbGFtL3NjaGVtYS9wb2xpY3kvdjEuMSI+PG5zMzp1cmw+aHR0cHM6Ly93d3cuY2FyZGlmb25saW5lLmNvbS5teC9QU05UXGo3bm50dnl1dnpcajdubnR2eXV2ejA1LjAyMDIwMjUzNTUwMDI1MzYucGRmPC9uczM6dXJsPjwvcmV0dXJuPjwvZ2V0Q2VydGlmaWNhZG9SZXNwb25zZT4=", "AF8032F6EE23648AFB66728C7FA88209");
//				System.out.println("fff: "+fff);
//
//			} catch (InvalidKeyException | NoSuchAlgorithmException
//					| NoSuchPaddingException | IllegalBlockSizeException
//					| BadPaddingException | DecoderException e) {
//				e.printStackTrace();
//			} catch (InvalidAlgorithmParameterException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			System.out.println("Termina petici�n..."+ new Date());
//			System.out.println("Tiempo transcurrido en login TOTAL:"+ ( time_end - time_start )/1000 +" Segundos");

		}
//		
		


//	}
	//AF8032F6EE23648AFB66728C7FA88209 Scotiabank
	//577e3462c55d23c8941d531b36e2a328 eficasia
	
	public static void saveVenta(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
		;//Variables para medir tiempos de respuestas
		    
			//ProfilesIni profile = new ProfilesIni(); 
	    	//FirefoxProfile myprofile = profile.getProfile("profileQA");
	    	//driver = new FirefoxDriver(myprofile);
			/**************1. Formar el XML request*************/
			//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
	      //String xmlRequest= "D:\\Work\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\SaveSellHPTC.xml";//venta
		  String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";//certificado

			try {
				
					
				mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
				MessageWrapped msgWrapped = new MessageWrapped();
				
				/**************2. Generar el objeto del request*************/
						ObjectRequest objectRequest= new ObjectRequest();
						//Ip del equipo desde donde se realiza la petici�n
						objectRequest.setIpClient("172.17.187.184");
						//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
						//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
						objectRequest.setKeyChiperedAES("AF8032F6EE23648AFB66728C7FA88209");
						//MacAddress de quien realiza la invocaci�n del servicio
						objectRequest.setMacAddressClient("12-ED-34-FR-DE");
						//Mandar el XML del la operaci�n Request en String
						objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
						//Nombre del usuario que realiza la petici�n
						objectRequest.setName("LizzyLoV");
						//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
					    //certificado	objectRequest.setServiceCd("274");
						//objectRequest.setServiceCd("273");//vENTA
						objectRequest.setServiceCd("273");//Certificado

						//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
						objectRequest.setThirdPartyCode("4");
						
					

						objectRequest.setToken(token);

						//credencial del usuario que est� realizando la petici�n
						objectRequest.setUserRequest("LizzyLoV");
						
				/**************3. Cifrar el msj del request*************/		
				//Cifrar el Mensaje de Request
				String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
				
				System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

				msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
				
//				msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
				
			    msgWrapped.setThirdPartyCode("4");
			    
				/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
			    
				//Se genera la petici�n Request del Bus
				Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
				time_start2 = (double) System.currentTimeMillis();
				MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
				time_end2 = (double) System.currentTimeMillis();
				System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/500 +" Segundos");
				System.out.println("new Time():"+new Date());

	            //Mensaje cifrada de la respuesta del Bus
				String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
				
				/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
				//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
				String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "AF8032F6EE23648AFB66728C7FA88209");
				                                                                           
				
				System.out.println("respuesta des cifrada: "+new Date()+"   :: "+respuestaDescifrada);
				Pattern patternUrl = Pattern.compile("url>(.+?)</ns3");
				 Matcher matcherUrl = patternUrl.matcher(respuestaDescifrada);
				 matcherUrl.find();
				System.out.println("URL:"+matcherUrl.group(1).toString());
				
				/*
		   
	     	
	        
	       
	        baseUrl = "https://172.17.186.219:8443/";
				 */
				
				
			  }catch (MalformedURLException e) {
					e.printStackTrace();
				}
				catch(Exception e){
					e.printStackTrace();
				}
			
		}
	
	 public static String muestraContenido(String archivo) throws FileNotFoundException, IOException {
	        String cadena;
	        String cadenaReturn="";
	        FileReader f = new FileReader(archivo);
	        BufferedReader b = new BufferedReader(f);
	        while((cadena = b.readLine())!=null) {
	            cadenaReturn= cadenaReturn+cadena;
	        }
	        b.close();
	        return cadenaReturn;
	    }
	 
	 public static void getCertified(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
					//Intanciando objeto del Cliente
								
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.184");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							//9BE28BF779C47EAC398E99DD742C311A cardif Zuctivo
							//
							objectRequest.setKeyChiperedAES("FC460BC243B25812B102670836BDB029");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("TEST TEST");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
							objectRequest.setServiceCd("274");
							//objectRequest.setServiceCd("285");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("1");
	
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("TEST");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
					
//					msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
					
				    msgWrapped.setThirdPartyCode("1");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
//					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
//					System.out.println("new Time():"+new Date());

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "FC460BC243B25812B102670836BDB029");
					
					System.out.println("respuesta des cifrada: "+new Date()+"   :: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 //263 SUMARY, 264 DETAIL CLAIMS, 265 SUMARY COLLECTION , 266 DETAIL COLLECTION, 267 SUMARY SUSCRIPTION, 268 DETAIL SUSCRIPTION
	 public static void pruebaclaimsPrincipal(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
					//Intanciando objeto del Cliente
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.233");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("577e3462c55d23c8941d531b36e2a328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("TEST");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    objectRequest.setServiceCd("263"); //Z
							//objectRequest.setServiceCd("263"); //dev

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("2"); //Z
					//		objectRequest.setThirdPartyCode("3"); //DEV

							//Token Generado del SESAME
//						    LoginRequest login= new LoginRequest();
//						    login.setUser("SAC4");
//						    login.setPassword("S4C*12579");
//						    
//						    
//						    
//							Double     time_start = new Double("0.0"), time_end= new Double("0.0");
//							time_start = (double) System.currentTimeMillis();
//						    LoginResponse response= serviceServiceagent.getPortTypeEndpoint().login(login);
//							time_end = (double) System.currentTimeMillis();
//							System.out.println("Tiempo transcurrido en login TOTAL:"+ ( time_end - time_start )/1000 +" Segundos");
//							System.out.println("Token: "+response.getToken());
////							
////							
//					objectRequest.setToken(response.getToken());
							
							
							//9fcf9777ba49a94a025435b4697d72b27c282595 9:46 12:08 no
							//6ff950ca0066a7192856d1cee9d993de745e6d6d 
							//a7b7f47d18d3d4aefd6729e72088cbd6a4920bb4
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("Test");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

//					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
//					
////					msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
//					
//				    msgWrapped.setThirdPartyCode("3");
//				    
//					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
//				    
//					//Se genera la petici�n Request del Bus
//					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
//					time_start2 = (double) System.currentTimeMillis();
//					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
//					time_end2 = (double) System.currentTimeMillis();
//					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
//					System.out.println("new Time():"+new Date());
//
//		            //Mensaje cifrada de la respuesta del Bus
//					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
//					
//					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
//					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
//					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "577e3462c55d23c8941d531b36e2a328");
//					
//					System.out.println("respuesta des cifrada: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}

	 public static void pruebaclaimsDetalle(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.111");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("577e3462c55d23c8941d531b36e2a328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("TEST");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("264");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("2"); //Z
					//		objectRequest.setThirdPartyCode("3"); //DEV
							//Token Generado del SESAME
																
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("TEST");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

//					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
//										
//				    msgWrapped.setThirdPartyCode("2");
//				    
//					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
//				    
//					//Se genera la petici�n Request del Bus
//					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
//					time_start2 = (double) System.currentTimeMillis();
//					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
//					time_end2 = (double) System.currentTimeMillis();
//					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
//					System.out.println("new Time():"+new Date());
//
//		            //Mensaje cifrada de la respuesta del Bus
//					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
//					
//					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
//					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
//					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "577e3462c55d23c8941d531b36e2a328");
//					
//					System.out.println("respuesta des cifrada: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 public static void pruebaSuscriptionList(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.333");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("577e3462c55d23c8941d531b36e2a328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("TEST");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("267");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("2"); //Z
					//		objectRequest.setThirdPartyCode("3"); //DEV
							//Token Generado del SESAME
																
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("TEST");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

//					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
//										
//				    msgWrapped.setThirdPartyCode("2");
//				    
//					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
//				    
//					//Se genera la petici�n Request del Bus
//					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
//					time_start2 = (double) System.currentTimeMillis();
//					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
//					time_end2 = (double) System.currentTimeMillis();
//					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
//					System.out.println("new Time():"+new Date());
//
//		            //Mensaje cifrada de la respuesta del Bus
//					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
//					
//					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
//					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
//					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "577e3462c55d23c8941d531b36e2a328");
//					
//					System.out.println("respuesta des cifrada: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 public static void pruebaCollectionList(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.222");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("577e3462c55d23c8941d531b36e2a328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("TEST");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("265");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("2"); //Z
					//		objectRequest.setThirdPartyCode("3"); //DEV
							//Token Generado del SESAME
																
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("TEST");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

//					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
//										
//				    msgWrapped.setThirdPartyCode("2");
//				    
//					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
//				    
//					//Se genera la petici�n Request del Bus
//					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
//					time_start2 = (double) System.currentTimeMillis();
//					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
//					time_end2 = (double) System.currentTimeMillis();
//					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
//					System.out.println("new Time():"+new Date());
//
//		            //Mensaje cifrada de la respuesta del Bus
//					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
//					
//					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
//					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
//					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "577e3462c55d23c8941d531b36e2a328");
//					
//					System.out.println("respuesta des cifrada: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 public static void saveTransaction(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.184");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("0E62009B134EC807DB344ED1FE8AF328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("FLORICELDA CABRERA");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("281");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("1");
							//Token Generado del SESAME
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("FCABRERA");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
										
				    msgWrapped.setThirdPartyCode("1");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
//					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
//					System.out.println("new Time():"+new Date());

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "0E62009B134EC807DB344ED1FE8AF328");
					
					System.out.println("respuesta des cifrada: "+new Date()+"   :: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 
	 public static void validTransaction(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.184");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("AF8032F6EE23648AFB66728C7FA88209");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("FLORICELDA CABRERA");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("271");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("4");
							//Token Generado del SESAME
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("FCABRERA");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
										
				    msgWrapped.setThirdPartyCode("4");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
					System.out.println("new Time():"+new Date());

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "AF8032F6EE23648AFB66728C7FA88209");
					
					System.out.println("respuesta des cifrada: "+new Date()+"   :: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}

	 public static void validTransactionIsPaid(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
					
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.184");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("AF8032F6EE23648AFB66728C7FA88209");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("FLORICELDA CABRERA");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("272");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("4");
							//Token Generado del SESAME
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("FCABRERA");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
										
				    msgWrapped.setThirdPartyCode("4");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
					System.out.println("new Time():"+new Date());

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "AF8032F6EE23648AFB66728C7FA88209");
					
					System.out.println("respuesta des cifrada: "+new Date()+"   :: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 public static void doTransaction(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.184");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("0E62009B134EC807DB344ED1FE8AF328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("FLORICELDA CABRERA");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("286");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("1");
							//Token Generado del SESAME
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("FCABRERA");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
										
				    msgWrapped.setThirdPartyCode("1");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					
					System.out.println("msgWrappedResponse:"+msgWrappedResponse);

					time_end2 = (double) System.currentTimeMillis();
					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
					System.out.println("new Time():"+new Date());

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "0E62009B134EC807DB344ED1FE8AF328");
					
					System.out.println("respuesta des cifrada: "+new Date()+"   :: "+respuestaDescifrada);
					
	//dVKEi8CM+QG8Pe9FrhSjMbm8xNwdc1UjgY6pL0G0pUrTP4WkkSe8wK4ltjbfTRRH7TkFQydPJJ/eMNpcHemybH7vzd4WOFeeW4dftPkxX6RUEwsW+mIJqbG9mL/0C74uIbCp6SvTd9F5MGggIWV7rgoK6oCdz5IdRK190zpLR2e5CfhKwA40LrLAVLBeXVIqfRIL57+fRmNz8TF4bV60vRIQFJz4NzpNIxN/KtSPdaqi4xdPeTWrVYDGeuDaqceqxxycKPNuwKPatM4dSSP0OYk9QaVVWz3jMrYvdAcBZ/TDINmD3VvacHSdqmXWq92N59oOQZEnCjSfB6uZ/DJ2OBIbb+EtpQLR0P08oXo0PRBu0oh/0ppwVDssH0TcnOMkOFB/ZdfJ2euZOO5YGWA+hvRn2fqHmr5blU1CpKmK9DlnYcE+xaJl+//fLHHKIErvT25FoDbPN2qzouW2z8ZQPx16h9RGiyVMRPxfTgN7zqRqkQH6pYgubUFQIwd5nsqWucyNBDkR2EKtdpKT0mlw2CMeWa+7C8Ps3KzmN1ltxdE=
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 public static void pruebaSuscriptionDetalle(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.554");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("577e3462c55d23c8941d531b36e2a328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("TEST");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("268");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("2");
							//Token Generado del SESAME
																
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("TEST");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
										
				    msgWrapped.setThirdPartyCode("2");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
					System.out.println("new Time():"+new Date());

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "577e3462c55d23c8941d531b36e2a328");
					
					System.out.println("respuesta des cifrada: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 
	 public static void pruebaCollectionDetalle(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
				String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";

				try {
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.222");
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("577e3462c55d23c8941d531b36e2a328");
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("TEST");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("266");

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("2");
							//Token Generado del SESAME
																
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("TEST");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("Petici�n cifrada: "+msjCifradoenAES128);

//					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
//										
//				    msgWrapped.setThirdPartyCode("2");
//				    
//					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
//				    
//					//Se genera la petici�n Request del Bus
//					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
//					time_start2 = (double) System.currentTimeMillis();
//					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
//					time_end2 = (double) System.currentTimeMillis();
//					System.out.println("Tiempo transcurrido en sendMessage TOTAL:"+ ( time_end2 - time_start2 )/1000 +" Segundos");
//					System.out.println("new Time():"+new Date());
//
//		            //Mensaje cifrada de la respuesta del Bus
//					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
//					
//					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
//					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
//					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "577e3462c55d23c8941d531b36e2a328");
//					
//					System.out.println("respuesta des cifrada: "+respuestaDescifrada);
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}

	 
}
