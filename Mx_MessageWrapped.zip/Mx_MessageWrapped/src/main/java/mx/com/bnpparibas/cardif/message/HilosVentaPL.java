package mx.com.bnpparibas.cardif.message;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.io.File;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

import java.io.PrintStream;


public class HilosVentaPL extends Thread{

public static void main(String[] s) throws InterruptedException
{
	
	try
		{
		   String Num = getNum();
	
		   PrintStream fichero = new PrintStream(new File("D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\SaveSell\\RCSaveSell-"+Num+".txt"));
		    
		   System.setOut(fichero);	

			Calendar calendario = Calendar.getInstance();
			System.out.println("-----------------------------------------------------");
			System.out.println(">>> Inicia Ejecuci�n de Hilos <<<");
			System.out.println(calendario.getTime());
			System.out.println("-----------------------------------------------------\n\n");
				
			
			for(int i=1; i<=20;i++)
				
			{							
				
			HilosVentaPL test = new HilosVentaPL();
							
			test.start();
			Thread.sleep(4000);
			}
			
						
		}

			catch(Throwable e)
			{	
				Calendar TExp = Calendar.getInstance();
				System.out.println(" Exception Hilo -->"+ TExp.getTime());
				System.out.println("------------------------------------------------");
				
				e.printStackTrace();
			}
	


			
} 
			

public void run()
{
	
    
    	  	
	try {
		this.runHilos();
		Thread.sleep(2000);
		
	}
	
	catch (Throwable e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}		
	//
    
  

}
	
	
	public void runHilos() throws XPathExpressionException, SAXException, IOException, ParserConfigurationException, TransformerFactoryConfigurationError, TransformerException, Throwable
	{
		
		
				PruebasLiz2 venta = new PruebasLiz2(); //Venta
			    
			    
			    venta.Test();
			    //Thread.sleep(5000);
			
		
		
	}
	
	 public static String getNum(){
			char[] chars = "1234567890".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int i = 0; i < 6; i++) {
				char c = chars[random.nextInt(chars.length)];
				sb.append(c);
			}
			String output = sb.toString();

			return output;
		}


	 
 } 






