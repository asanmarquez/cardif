package mx.com.bnpparibas.cardif.message.helper;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import mx.com.bnpparibas.cardif.message.dto.ObjectRequest;

import org.apache.commons.io.IOUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/************************************************************************************************
 *                                ID:MEX0151 POSNET E-LAM                                       *
 *  *********************************************************************************************
 *   Fecha: 24/01/2018                                                                          *
 *   Descripci�n:Clase que maneja el xml del globalMessage                                      *
 *   @author: Floricelda Cabrera Santos                                                         *
 * **********************************************************************************************/
public class GlobalMessageAdapter {
	/**
	 * @param ObjectRequest objectRequest
	 * @return Boolean
	 * @throws SAXException
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws XPathExpressionException
	 * @throws TransformerFactoryConfigurationError
	 * @throws TransformerException
	 */
	public synchronized Boolean generarGlobalMessage(ObjectRequest objectRequest, Long timeRequest) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
        Boolean resultado = false;
		PropertiesFile propertiesFile = new PropertiesFile();
		String pathPrincipal = propertiesFile.getProperties().getProperty(propertiesFile.getPathXmlPrincipales());

        final String inputFile = pathPrincipal+"globalMessageRequestTemplate.xml";
        final String outputFile = pathPrincipal+"globalMessageRequest"+timeRequest+".xml";

		Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(inputFile));
		XPath xpath = XPathFactory.newInstance().newXPath();

		//ServiceCd
		NodeList nodeServiceCd = (NodeList)xpath.evaluate("//Route//Application/ServiceCd[text()='ServiceCd']", doc, XPathConstants.NODESET);  
		nodeServiceCd.item(0).setTextContent(objectRequest.getServiceCd());

		//partyId
		NodeList partyId = (NodeList)xpath.evaluate("//Route//Sender/PartyId[text()='PartyId']", doc, XPathConstants.NODESET);  
		partyId.item(0).setTextContent(objectRequest.getThirdPartyCode()); 

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Instant instant = timestamp.toInstant();

		//TimeStamp
		NodeList nodeTimeStamp = (NodeList)xpath.evaluate("//Route/TimeStamp[text()='TimeStamp']", doc, XPathConstants.NODESET);  
		nodeTimeStamp.item(0).setTextContent(instant.toString());

		//Token
		NodeList nodetoken = (NodeList)xpath.evaluate("//Message//UserAccess/token[text()='token']", doc, XPathConstants.NODESET);  
		nodetoken.item(0).setTextContent(objectRequest.getToken());

		//ipRequest
		NodeList nodeipRequest = (NodeList)xpath.evaluate("//Message//UserDetailMetadata/ipRequest[text()='ipRequest']", doc, XPathConstants.NODESET);  
		nodeipRequest.item(0).setTextContent(objectRequest.getIpClient());

		//macRequest
		NodeList nodemacRequest = (NodeList)xpath.evaluate("//Message//UserDetailMetadata/macRequest[text()='macRequest']", doc, XPathConstants.NODESET);  
		nodemacRequest.item(0).setTextContent(objectRequest.getMacAddressClient());

		//credencialUser
		NodeList nodes = (NodeList)xpath.evaluate("//Message//UserDetailMetadata/userRequest[text()='userRequest']", doc, XPathConstants.NODESET);
		nodes.item(0).setTextContent(objectRequest.getUserRequest());
		
		//name
		NodeList nodes1 = (NodeList)xpath.evaluate("//Message//UserDetailMetadata/name[text()='name']", doc, XPathConstants.NODESET);  
		nodes1.item(0).setTextContent(objectRequest.getName());

		//MsgItem
		NodeList nodeMsgItem = (NodeList)xpath.evaluate("//Message//MsgItem[text()='MsgItem']", doc, XPathConstants.NODESET);  
		nodeMsgItem.item(0).setTextContent(objectRequest.getMsgItemXml());

		// save the result
		Transformer xformer = TransformerFactory.newInstance().newTransformer();
		File outFile = new File(outputFile);
		Boolean fileCreate = outFile.createNewFile();
		//System.out.println("--> File:"+outputFile+fileCreate);
		xformer.transform(new DOMSource(doc), new StreamResult(outFile));
		resultado = true;
		
		return resultado;
	}
}
