package mx.com.bnpparibas.cardif.message.helper;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.naming.ConfigurationException;


public class PropertiesFile {
	private Properties 	properties;
	private static final String PATH_XML_PRINCIPALES = "bus.path.xml";
	
	
	public PropertiesFile(){
		this.properties = new Properties();
		try {
			validateFilePropertiesLogs();
		} catch (ConfigurationException e) {
			e.printStackTrace();
		}
	}
	
	private void validateFilePropertiesLogs() throws ConfigurationException{
		InputStream input = null;
		try {			 
			input = new FileInputStream("C:\\aplicationConfig\\Bus\\configuration.properties");
			                            
			// Load a properties file
			properties.load(input);
	 
			String[] itemProperties = { PATH_XML_PRINCIPALES };
			for(int indexPropertie = 0; indexPropertie < itemProperties.length; indexPropertie++){
				String property = properties.getProperty(itemProperties[indexPropertie]);
				if(property == null){
					throw new ConfigurationException("Propertie value [".concat(itemProperties[indexPropertie]).concat("] is not present in file config"));
				}
			}	 
		} catch (IOException ex) {
			throw new ConfigurationException("Propertie file ["+input+"] is not present");
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public static String getPathXmlPrincipales() {
		return PATH_XML_PRINCIPALES;
	}	
	
}
