package mx.com.bnpparibas.cardif.message.dto;
/***********************************************************************************************
*                                ID:MEX0151 POSNET E-LAM                                       *
*  *********************************************************************************************
*   @date: 24/01/2018                                                                          *
*   Descripci�n:Clase que transporta los par�metros del request para formar el messageWrapped  *	 
*   @author: Floricelda Cabrera Santos                                                         *
* **********************************************************************************************/
public class ObjectChiperedRequest {
	private String globalMessageChipered;
	private String thirdPartyCode;
    private String msgItemChipered;
    
    
	public String getGlobalMessageChipered() {
		return globalMessageChipered;
	}
	public void setGlobalMessageChipered(String globalMessageChipered) {
		this.globalMessageChipered = globalMessageChipered;
	}
	public String getThirdPartyCode() {
		return thirdPartyCode;
	}
	public void setThirdPartyCode(String thirdPartyCode) {
		this.thirdPartyCode = thirdPartyCode;
	}
	public String getMsgItemChipered() {
		return msgItemChipered;
	}
	public void setMsgItemChipered(String msgItemChipered) {
		this.msgItemChipered = msgItemChipered;
	}
    
    

}
