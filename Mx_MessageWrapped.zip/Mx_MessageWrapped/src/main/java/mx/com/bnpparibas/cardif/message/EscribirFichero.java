package mx.com.bnpparibas.cardif.message;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Calendar;
import java.util.Random;

public class EscribirFichero {

    public static void main(String[] args) throws IOException {
    	
       	String Num = getNum();
        String ruta = "D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\SaveSell\\RCSaveSell-"+Num+".txt";
        File archivo = new File(ruta);
        File archivo2 = new File(ruta);
                
        
            	for(int i=1; i<=2;i++)
				
			{							
				
			 BufferedWriter bw;
       // if(archivo.exists()) {
            bw = new BufferedWriter(new FileWriter(archivo));
            //bw.write("El fichero de texto ya estaba creado.");
           		
			HilosVentaPL test = new HilosVentaPL();
							
			test.start();
			//} else {
            //bw = new BufferedWriter(new FileWriter(archivo2));
            	
			//HilosVentaPL test = new HilosVentaPL();
							
			test.start();
			
			bw.close();
			
        }  
			
			} 
            

      
    
    
    public void run()
    {
    	
        try {
        	
        	
        String Num = getNum();
    	PrintStream fichero = new PrintStream(new File("D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\SaveSell\\RCSaveSell-"+Num+".txt"));
        System.setOut(fichero);		
    	this.runHilos();		

        
        }

    	catch (IOException e) {
    		System.out.println("***** Fall� Ejecuci�n de Hilos. *****\n");
    	    e.printStackTrace();
    	} 

    }
    	
    	
    	public void runHilos()
    	{
    		
    		try
    		{
    		
    				PruebasLiz2 venta = new PruebasLiz2(); //Venta

    			    venta.Test();
    	      
    		}	
    		
    		catch(Throwable e)
    		{	
    			Calendar TExp = Calendar.getInstance();
    			System.out.println(" Exception Hilo -->"+ TExp.getTime());
    			System.out.println("------------------------------------------------");
    			
    			e.printStackTrace();
    		}
    		
    	}
    	
    
	 public static String getNum(){
			char[] chars = "1234567890".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int i = 0; i < 6; i++) {
				char c = chars[random.nextInt(chars.length)];
				sb.append(c);
			}
			String output = sb.toString();

			return output;
		}

}