package mx.com.bnpparibas.cardif.message.dto;
/***********************************************************************************************
*                                ID:MEX0151 POSNET E-LAM                                       *
*  *********************************************************************************************
*   @date: 24/01/2018                                                                          *
*   Descripci�n:Clase que transporta los par�metros del request para la codificaci�n del msg   *	 
*   @author: Floricelda Cabrera Santos                                                         *
* **********************************************************************************************/
public class ObjectRequest {
	private String serviceCd;
	private String token;
	private String userRequest;
	private String name;
	private String msgItemXml;
	private String ipClient;
	private String macAddressClient;
	private String keyChiperedAES;
	private String thirdPartyCode;



	public ObjectRequest() {
		this.serviceCd ="";
		this.token ="";
		this.userRequest ="";
		this.name ="";
		this.msgItemXml ="";
		this.ipClient="";
		this.macAddressClient="";
		this.keyChiperedAES="";
		this.thirdPartyCode="";
	}
	
	/**
	 * @return the serviceCd
	 */
	public String getServiceCd() {
		return serviceCd;
	}
	/**
	 * @param serviceCd the serviceCd to set
	 */
	public void setServiceCd(String serviceCd) {
		this.serviceCd = serviceCd;
	}
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * @return the userRequest
	 */
	public String getUserRequest() {
		return userRequest;
	}
	/**
	 * @param userRequest the userRequest to set
	 */
	public void setUserRequest(String userRequest) {
		this.userRequest = userRequest;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the ipClient
	 */
	public String getIpClient() {
		return ipClient;
	}
	/**
	 * @param ipClient the ipClient to set
	 */
	public void setIpClient(String ipClient) {
		this.ipClient = ipClient;
	}
	/**
	 * @return the macAddressClient
	 */
	public String getMacAddressClient() {
		return macAddressClient;
	}
	/**
	 * @param macAddressClient the macAddressClient to set
	 */
	public void setMacAddressClient(String macAddressClient) {
		this.macAddressClient = macAddressClient;
	}

	public String getMsgItemXml() {
		return msgItemXml;
	}

	public void setMsgItemXml(String msgItemXml) {
		this.msgItemXml = msgItemXml;
	}

	public String getKeyChiperedAES() {
		return keyChiperedAES;
	}

	public void setKeyChiperedAES(String keyChiperedAES) {
		this.keyChiperedAES = keyChiperedAES;
	}

	public String getThirdPartyCode() {
		return thirdPartyCode;
	}

	public void setThirdPartyCode(String thirdPartyCode) {
		this.thirdPartyCode = thirdPartyCode;
	}

	
}
