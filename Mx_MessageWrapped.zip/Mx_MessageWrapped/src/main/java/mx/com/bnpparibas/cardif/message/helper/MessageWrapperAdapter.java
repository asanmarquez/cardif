package mx.com.bnpparibas.cardif.message.helper;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import mx.com.bnpparibas.cardif.message.dto.ObjectChiperedRequest;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
/************************************************************************************************
 *                                ID:MEX0151 POSNET E-LAM                                       *
 *  *********************************************************************************************
 *   Fecha: 30/01/2018                                                                          *
 *   Descripci�n:Clase que genera el xml de messageWrapped con el mensaje cifrado      	        *
 *   @author: Floricelda Cabrera Santos                                                         *
 * **********************************************************************************************/
public class MessageWrapperAdapter {
	public Boolean generarMessageWrapped(ObjectChiperedRequest objectChiperedRequest) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
		PropertiesFile propertiesFile= new PropertiesFile();
		String pathPrincipal = propertiesFile.getProperties().getProperty(propertiesFile.getPathXmlPrincipales());
		
		final String inputFile = System.getProperty(pathPrincipal+"messageWrappedRequestTemplate.xml");
		final String outputFile = System.getProperty(pathPrincipal+"messageWrappedRequest.xml");

		Boolean resultado = false;
  
		Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(inputFile));
		XPath xpath = XPathFactory.newInstance().newXPath();

		//ServiceCd
		NodeList nodeServiceCd = (NodeList)xpath.evaluate("//Body//MessageWrapped/ChiperedMessage[text()='ChiperedMessage']", doc, XPathConstants.NODESET);  
		nodeServiceCd.item(0).setTextContent(objectChiperedRequest.getGlobalMessageChipered());

		//TimeStamp
		NodeList nodeTimeStamp = (NodeList)xpath.evaluate("//Body//MessageWrapped/ThirdPartyCode[text()='ThirdPartyCode']", doc, XPathConstants.NODESET);  
		nodeTimeStamp.item(0).setTextContent(objectChiperedRequest.getThirdPartyCode());

				// save the result
		Transformer xformer = TransformerFactory.newInstance().newTransformer();
		xformer.transform(new DOMSource(doc), new StreamResult(new File(outputFile)));
		resultado = true;
		
		return resultado;
	}
}
