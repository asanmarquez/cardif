package mx.com.bnpparibas.cardif.message;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.NamingException;

import javax.xml.namespace.QName;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.xpath.XPathExpressionException;
import mx.com.bnpparibas.cardif.message.dto.ObjectRequest;
import org.xml.sax.SAXException;
import com.bnpparibas.cardif.mx.schema.authentication.v1.LoginRequest;
import com.bnpparibas.cardif.mx.schema.authentication.v1.LoginResponse;
import com.bnpparibas.cardif.mx.schema.facade.ServiceServiceagent;
import com.bnpparibas.cardif.mx.schema.wrapped_message.v1.MessageWrapped;





//@Test

public class PruebasBI83 {
static ServiceServiceagent serviceServiceagent= null;
public static void main(String[] s) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException, NamingException {
//public  void Test() throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException, Throwable {

		//Intanciando objeto del Cliente
		 serviceServiceagent= new ServiceServiceagent(
				//LA IP DEL WSDL FAVOR DE DEJARLO DIN�MICA O CONFIGURABLE
				//new URL("http://172.17.186.83:7790/Services/Service.serviceagent?wsdl"), //URL BUS INTERNO QA/DEV
				new URL("http://172.17.186.152:7790/Services/Service.serviceagent?wsdl"), //URL BUS INTERNO UAT
				new QName("http://cardif.bnpparibas.com/mx/schema/facade", "Service.serviceagent")
				);

		LoginRequest login = new LoginRequest();
		/*
		login.setApplicationId("SESAME");
		login.setLogin("APP_MX_CertificadoFIU");
		login.setPassword("P@ss_61977");
		*/
		
		login.setApplicationId("SESAME");
		login.setLogin("APP_MX_PartnerSAC");
		login.setPassword("P@ss_19771");
		

		LoginResponse response= serviceServiceagent.getPortTypeEndpoint().login(login);
		///*
	    try {
	       
	    String Num = getNum();
	  
	    
	  // PrintStream fichero = new PrintStream(new File("D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\SaveSell\\RCSaveSell-"+Num+".txt"));
	    //PrintStream fichero = new PrintStream(new File("D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\getCertified\\RCgetCertified-"+Num+".txt"));
		//PrintStream fichero = new PrintStream(new File("D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\validTransaction\\RCvalidTransaction-"+Num+".txt"));
	    // PrintStream fichero = new PrintStream(new File("D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\SaveTransaction\\RCSaveTransaction-"+Num+".txt"));
	    //PrintStream fichero = new PrintStream(new File("D:\\WorkSpace\\Mx_MessageWrapped\\Respuesta Consola\\ReadTransactionIsPaid\\RCReadTransactionIsPaid-"+Num+".txt"));
	   
	   //System.setOut(fichero);	 
	   System.out.println("----------------------------------------");
	   System.out.println("***** Inician Peticiones por Hilo *****");
	   System.out.println("----------------------------------------\n");	
       Calendar calendario = Calendar.getInstance();
 
	  // System.out.println("  "+ calendario.getTime() + " \n");
	   Double time_start22 = new Double("0.0"),time_end22 = new Double("0.0");
	   time_start22 = (double) System.currentTimeMillis();
		
	    for(int x=1; x<=1;x++){
	    	
	    	System.out.println("------------------------------------");	
			System.out.println("--> Pentici�n #: "+ x);			
			
			System.out.println("--> Token: "+response.getToken());
	    	
			System.out.println("--> Tipo Operaci�n: SaveSell");
			
			SaveSell(response.getToken());	
			//getCertified(response.getToken());
			//validTransaction(response.getToken());
			//SaveTransaction(response.getToken());
			//ReadTransactionIsPaid(response.getToken());
	    	
			
		}	 
	    System.out.println("-----------------------------------------");				
		System.out.println("***** Finalizan Peticiones por Hilo  *****");
		System.out.println("----------------------------------------\n");
	    System.out.println("--> Fecha Ini: "+ calendario.getTime() );
	    time_end22 = (double) System.currentTimeMillis(); 
		System.out.println("--> Fecha Fin: "+new Date());
		System.out.println("--> Tiempo transcurrido en generar la venta TOTAL: ["+ ( time_end22 - time_start22 ) +" Milisegundos / "+ ( time_end22 - time_start22 )/1000 +" Segundos]");
	     System.out.println("------------------------------------------\n");
	    // Thread.sleep(2000);
			
		/*
		274	Reportes::GetCertified	*
		273	Sales::SaveSell (VENTA)	*
		272	PayOnline::ReadTransactionIsPaid	*
		271	PayOnline::ValidTransaction	*
		270	PayOnline::SaveTransaction	*
		
		
		*/



		        
	    } catch (IOException e) {
	    	System.out.println("***** Fall� la Operaci�n. *****\n");
	        e.printStackTrace();
	    } 
	    
	
	           
	}  
	//AF8032F6EE23648AFB66728C7FA88209 Scotiabank
	//577e3462c55d23c8941d531b36e2a328 eficasia
	        
	        
	
	public static void SaveSell(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
		;//Variables para medir tiempos de respuestas
		    
			//ProfilesIni profile = new ProfilesIni(); 
	    	//FirefoxProfile myprofile = profile.getProfile("profileQA");
	    	//driver = new FirefoxDriver(myprofile);
			/**************1. Formar el XML request*************/
			//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
			String xmlRequest= "C:\\Workspace\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveSell\\HP\\SaveSellRequest2.xml";//venta
		//String xmlRequest= "C:\\Users\\986545\\Desktop\\XML-Beneficiarios3.xml";//venta
		    

			try {
				
					
				mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
				MessageWrapped msgWrapped = new MessageWrapped();
				
				/**************2. Generar el objeto del request*************/
						ObjectRequest objectRequest= new ObjectRequest();
						//Ip del equipo desde donde se realiza la petici�n
						objectRequest.setIpClient("172.17.187.61");//184
						//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
						//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
						objectRequest.setKeyChiperedAES("9BE28BF779C47EAC398E99DD742C311A"); // QA/DEV 9BE28BF779C47EAC398E99DD742C311A
						//objectRequest.setKeyChiperedAES("FC460BC243B25812B102670836BDB029"); // UAT
						//MacAddress de quien realiza la invocaci�n del servicio
						objectRequest.setMacAddressClient("12-ED-34-FR-DE");
						//Mandar el XML del la operaci�n Request en String
						objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
						//Nombre del usuario que realiza la petici�n
						objectRequest.setName("LizzyLoV");
						//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
					    //certificado	objectRequest.setServiceCd("274");
						objectRequest.setServiceCd("273");//SaveSell273
					

						//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
						objectRequest.setThirdPartyCode("1");
						
					

						objectRequest.setToken(token);

						//credencial del usuario que est� realizando la petici�n
						objectRequest.setUserRequest("LizzyLoV");
						
				/**************3. Cifrar el msj del request*************/		
				//Cifrar el Mensaje de Request
				//System.out.println("--> Fecha - Cifrar el Mensaje de Request: "+new Date());
				String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
				
				System.out.println("--> Petici�n cifrada: "+msjCifradoenAES128);
				//Thread.sleep(2000);

				msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
				
//				msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
				
			    msgWrapped.setThirdPartyCode("1");
			    
				/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
			    
				//Se genera la petici�n Request del Bus
				Double time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
				time_start2 = (double) System.currentTimeMillis();
				MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
				time_end2 = (double) System.currentTimeMillis();
				

	            //Mensaje cifrada de la respuesta del Bus
				String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
				//System.out.println("--> Fecha: "+new Date());
				//System.out.println("--> Tiempo transcurrido en sendMessage TOTAL: ["+ ( time_end2 - time_start2 ) +" Milisegundos / "+ ( time_end2 - time_start2 )/1000 +" Segundos]");
				
				/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
				//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
				String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "9BE28BF779C47EAC398E99DD742C311A"); // QA/DEV0E62009B134EC807DB344ED1FE8AF328
				//String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "FC460BC243B25812B102670836BDB029");//UAT
				
				
				//System.out.println(new Date());
				System.out.println("--> Respuesta Descifrada: "+ respuestaDescifrada);
				Pattern patternUrl = Pattern.compile("url>(.+?)</ns3");
				
				
				Matcher matcherUrl = patternUrl.matcher(respuestaDescifrada);
				 matcherUrl.find();
				System.out.println("--> URL del Certificado: "+matcherUrl.group(1).toString());
				System.out.println("--> Tiempo transcurrido en sendMessage TOTAL: ["+ ( time_end2 - time_start2 ) +" Milisegundos / "+ ( time_end2 - time_start2 )/1000 +" Segundos]");
				System.out.println("------------------------------------\n");	
				

			  }catch (MalformedURLException e) {
					e.printStackTrace();
														  
				}
				catch(Exception e){
					//e.printStackTrace();
					System.out.println("\n* Fall� el proceso de la venta\n\n"+e);
				}
			
		}
	
	
	 public static String muestraContenido(String archivo) throws FileNotFoundException, IOException {
	        String cadena;
	        String cadenaReturn="";
	        FileReader f = new FileReader(archivo);
	        BufferedReader b = new BufferedReader(f);
	        while((cadena = b.readLine())!=null) {
	            cadenaReturn= cadenaReturn+cadena;
	        }
	        b.close();
	        return cadenaReturn;
	    }
	 
	 public static void getCertified(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas

				/**************1. Formar el XML request*************/
			  //Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
			    String xmlRequest= "D:\\Work\\MensajesCifrados\\msgItem\\Flor\\Liz\\GetCertified\\GetCertifiedHP.xml";//certificado


			    try {
					
					
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.61");//184
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							objectRequest.setKeyChiperedAES("9BE28BF779C47EAC398E99DD742C311A"); // QA/DEV 0E62009B134EC807DB344ED1FE8AF328
							//objectRequest.setKeyChiperedAES("FC460BC243B25812B102670836BDB029"); // UAT
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("LizzyLoV");
							
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    
							objectRequest.setServiceCd("274");//Certificado

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("1");
	
							
							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("LizzyLoV");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("--> Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
					
//					msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
					
				    msgWrapped.setThirdPartyCode("1");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
					

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					System.out.println("--> Fecha: "+new Date());
					System.out.println("--> Tiempo transcurrido en sendMessage TOTAL: "+ ( time_end2 - time_start2 )/500 +" Segundos");
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "9BE28BF779C47EAC398E99DD742C311A"); // QA/DEV  0E62009B134EC807DB344ED1FE8AF328
					//String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "FC460BC243B25812B102670836BDB029");//UAT
					
					
			
					
					
					
					System.out.println("*** Operaci�n Validada: getCertified ***\n");
					//System.out.println(new Date());
					System.out.println("--> Respuesta Descifrada: "+ respuestaDescifrada);
					Pattern patternUrl = Pattern.compile("url>(.+?)</ns3");
     				Matcher matcherUrl = patternUrl.matcher(respuestaDescifrada);
					matcherUrl.find();
					System.out.println("--> URL del Certificado: "+matcherUrl.group(1).toString());
					System.out.println("\n--------------------------------");	
					
						
			
					
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					  
					}
					catch(Exception e){
						
						System.out.println("\n* Fall� el proceso de generar el certificado de la venta: \n\n"+ e);
						//e.printStackTrace();
						
					}
				
			}
	 
	 
	 public static void validTransaction(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas
			    
				//ProfilesIni profile = new ProfilesIni(); 
		    	//FirefoxProfile myprofile = profile.getProfile("profileQA");
		    	//driver = new FirefoxDriver(myprofile);
				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
			    
		        String xmlRequest= "D:\\Work\\MensajesCifrados\\msgItem\\Flor\\Liz\\ValidTransaction\\ValidTransactionVac�oamount.xml";//certificado

				try {
					
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.61");//184
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							//objectRequest.setKeyChiperedAES("0E62009B134EC807DB344ED1FE8AF328"); // QA/DEV
							objectRequest.setKeyChiperedAES("9BE28BF779C47EAC398E99DD742C311A"); // UATFC460BC243B25812B102670836BDB029
							
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("LizzyLoV");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("271");//validTransaction
							

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("1");
							
						

							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("LizzyLoV");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("--> Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
					
//					msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
					
				    msgWrapped.setThirdPartyCode("1");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
					

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					System.out.println("--> Fecha: "+new Date());
					System.out.println("--> Tiempo transcurrido en sendMessage TOTAL: "+ ( time_end2 - time_start2 )/500 +" Segundos");
					
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					//String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "0E62009B134EC807DB344ED1FE8AF328"); // QA/DEV
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "FC460BC243B25812B102670836BDB029");//UAT
					
					System.out.println("\n--------------------------------");
					System.out.println("*** Operaci�n Validada: validTransaction ***\n");
					//System.out.println(new Date());
					System.out.println("* Abrir en un navegador la URL: https://www.base64decode.org/  \n* Posteriormente, copiar y pegar la respuesta cifrada: \n"+respuestaDescifrada);
					System.out.println("\n--------------------------------");
				
					
					
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
	 public static void SaveTransaction(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas
			    
				//ProfilesIni profile = new ProfilesIni(); 
		    	//FirefoxProfile myprofile = profile.getProfile("profileQA");
		    	//driver = new FirefoxDriver(myprofile);
				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
			     String xmlRequest= "D:\\Work\\MensajesCifrados\\msgItem\\Flor\\Liz\\SaveTransaction\\userTransaction\\SaveTransaction-userTransaction-Formato2.xml";//venta

				try {
					
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.61");//184
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 							
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							//objectRequest.setKeyChiperedAES("0E62009B134EC807DB344ED1FE8AF328"); // QA/DEV
							objectRequest.setKeyChiperedAES("FC460BC243B25812B102670836BDB029"); // UAT
							
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("LizzyLoV");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("270");//SaveTransaction
						

							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("1");
							
						

							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("LizzyLoV");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("--> Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
					
//					msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
					
				    msgWrapped.setThirdPartyCode("1");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
					

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					System.out.println("--> Fecha: "+new Date());
					System.out.println("--> Tiempo transcurrido en sendMessage TOTAL: "+ ( time_end2 - time_start2 )/500 +" Segundos");
					
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					//String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "0E62009B134EC807DB344ED1FE8AF328"); // QA/DEV
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "FC460BC243B25812B102670836BDB029");//UAT
					
					System.out.println("\n--------------------------------");
					System.out.println("*** Operaci�n Validada: SaveTransaction ***\n");
					//System.out.println(new Date());
					System.out.println("* Abrir en un navegador la URL: https://www.base64decode.org/  \n* Posteriormente, copiar y pegar la respuesta cifrada:\n"+respuestaDescifrada);
					System.out.println("\n--------------------------------");
				
					
					
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}
			
	 
	 public static void ReadTransactionIsPaid(String token) throws SAXException, IOException, ParserConfigurationException, XPathExpressionException, TransformerFactoryConfigurationError, TransformerException {
			;//Variables para medir tiempos de respuestas
			    
				//ProfilesIni profile = new ProfilesIni(); 
		    	//FirefoxProfile myprofile = profile.getProfile("profileQA");
		    	//driver = new FirefoxDriver(myprofile);
				/**************1. Formar el XML request*************/
				//Este XML se formar� en cada petici�n que se tenga que realizar al bus y acorde a las necesidades de cada operaci�n
			     String xmlRequest= "D:\\Work\\MensajesCifrados\\msgItem\\Flor\\Liz\\ReadTransactionIsPaid\\ReadTransactionIsPaidHP.xml";//venta

				try {
					
						
					mx.com.bnpparibas.cardif.message.MessageWrapped msgACifrar= new mx.com.bnpparibas.cardif.message.MessageWrapped();
					MessageWrapped msgWrapped = new MessageWrapped();
					
					/**************2. Generar el objeto del request*************/
							ObjectRequest objectRequest= new ObjectRequest();
							//Ip del equipo desde donde se realiza la petici�n
							objectRequest.setIpClient("172.17.187.61");//184
							//C�digo para Cifrar y Descifrar, esto depender� de cada Socio o cliente, 
							
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA
							//objectRequest.setKeyChiperedAES("0E62009B134EC807DB344ED1FE8AF328"); // QA/DEV
							objectRequest.setKeyChiperedAES("FC460BC243B25812B102670836BDB029"); // UAT
							
							
							//MacAddress de quien realiza la invocaci�n del servicio
							objectRequest.setMacAddressClient("12-ED-34-FR-DE");
							//Mandar el XML del la operaci�n Request en String
							objectRequest.setMsgItemXml(muestraContenido(xmlRequest));
							//Nombre del usuario que realiza la petici�n
							objectRequest.setName("LizzyLoV");
							//C�digo del Servicio que ser� invocado esto esta en el APPCTRL SVC_CAT_SERVICIOS
						    //certificado	objectRequest.setServiceCd("274");
							objectRequest.setServiceCd("272");//ReadTransactionIsPaid
							
							//este dato est� en APPCTRL USR_SOCIOS_COMPANIA.CODIGO
							objectRequest.setThirdPartyCode("1");
							
						

							objectRequest.setToken(token);

							//credencial del usuario que est� realizando la petici�n
							objectRequest.setUserRequest("LizzyLoV");
							
					/**************3. Cifrar el msj del request*************/		
					//Cifrar el Mensaje de Request
					String msjCifradoenAES128 = msgACifrar.cifrarMensaje(objectRequest);
					
					System.out.println("--> Petici�n cifrada: "+msjCifradoenAES128);

					msgWrapped.setChiperedMessage(msjCifradoenAES128);//Seteando el msj cifrado
					
//					msgWrapped.setChiperedMessage("u1yjxefICn4+HM8Q0lPHC/thOLdDbnCKCebUOL7MjYDOQ3PaPghzgw5Ck2jWFxpvkh1RLUkXHKb7TO/vPhJZWJH+YjlxXHpWXPk9cyZKe9tzaoNGLEkcjttyjHF9/fJ+1Plfj/puq+zhw2S8DAHfh47NjpuzYujzlWpTxeLk2pgXTy4Rcw2KHzkUC6IF23beZpX0m6EkTQQu98FICHEqa6rMoQYA+KBohK8eaQsGO2ld3eivG3SysQVjkZ9Q8wnjfJ/Bd3va2LVyKKpADChDPZEw9TGJ+fkWTopa8SD7eKxhtuTeqj5sOkIMTDIW1h8O5VbJ4QDvaioHzsaw4lpjoSksu34/BOFgbe3EhZDIV8/ySn5XYyTiOyW/PHSWrCy0hQw1g/zo1jDLZ/wlGLoOI7waAaMg6Ec3T2ul7QT6voTDMpYO3o0PtCuLI8NtJrw+P8UKlZlrmkWYcAMWbpCZZ+q7hw4nc0jXUFq8qudJ0TpyeiIzWGq1aZhKebBGFOF8QudYr43yFteVFYF+RaXRmxiB2YUCORdAiPIgh1bTY04YmQLtwGO0tZhGJGosCEbd9g2ZHfPlbPMzfsf1KscqAVYCskw0bOkzCkFyV69BDjL3FvKrHvwgNMu/BEr6zAsok3BJ5H5JKnU/mfa/6pL7/6rLOT0LHpuZ5f0CieQKnyK4fENKwy6nt4fTmLxsdnWhWrO3o+qg6dZ6s8vWRs1ksv44t6It0mVg9sUvjH3gTZsfHmTrracuwx/SeWDf1P1HH7F6/vSt0O9erAn2juRelHslmtTtVgQuqrGPXYJskVx6H03Wry4GtTfOOajbapprT+B06jjY9varQ2idnik8eyXrkeolo9L8lI+HRKYCmJrQ4yZQl+g73uDv5aBBeUuayp5jvKGyuZs8CzOm3jG3fVsaRC+wf2ncDKLLRF96qYzxBINleCHRNMJ4WuMB1KLSiNNpqdJYg8In+BP9jGEJSGsKMA+QXFqT1D0fpz7kHgtHfPs6pSjLQqBJp6BC0Fb13tjxF6YvobJwQ7q1F0C8WS+YREVZHbM1yptYGcj0GeqZAQCCkrAdZhUwz5lUUECBOX79S7KAEFqQ8+YqO0X31dsbMa6auKZ9jBCoP0io3/ZTpv5nb9YvdyshdZrnvA/WkYG0ZvXyM78CxsWvTqGNO1yPPVM6nrKqhoDGoPSRnVFfFVk86YxZj/kCuCw4TIXgndvzoJp2bxjF9SG+kqujrX0XNQnOEf/nk19ETz0TUtF3X4LyoFXPtceyHr3Tswd9ja44kQm3oBDbRrInkG4cT0jf1U9K9ptVWm18u1szzl6/Af0CgtajrnEfV3mOvASy3k0uX8JFwTxnxyyFIYk5eJDTU8u/eE0XNG3FCU6QXrf2UJrXBmZExKpt/8dKOpvDOuN65LPt9/CHRHEr7sitHJeQyOT6wwVpOMgYQMQNKua/BCF3yCl5U9tZmC8tubmVZJUoIHZkpVwzNY3keBOR/WKCGYRvAUVglh6vpyRko9mPaEctwrYFEyg/iTurs+Phg4lheBz+GWdcQ80YHpLDStO6GT1G2jLhLnGFAhSj0j8sEnBKT4g2Wtc+NW4adYpnUJpCdpLoSskNkM9WS/W7GDuzvwKHz8tlC+bMghsl501xYCCKiXZUvikQeslsgNOz7lzINjrPd9EtS4xIm6WgfhcHo2noSffWQ21Y+VyiQWUnxwgVCQVyQk8TAD/iSKhMWZIolaZ9jy+Q/MWRq3ICmQ7hPUQ/PBpZV0JsmqMBTDIOrmbzhfaMaaHY0EzeEOAbzU45HC9CuEf99EG5Ayf3MnhvGN5imRX2RMl6sjhinr1UrK4kbn9W6yKiqHOT6etGS55J36SLR5p4ybuWPyZcaTPF0QOf3d01TNIMIR74oQtxbWYBFkrfdnh9vn4GSe5NTi/nTdK3J5FPDq2uKXRSWtlOtRLHX0IehVa7bqtkS6SXqNaHKnCkFCV1RI5zr2I8SNGWe+4Z3/r3+ZZ/xWI6HQLg1hFomGYqq8ynsgM7pa0EEk1XTLREByVbg/AHY25Y6CYG0k7GJqZGzfYbfRcCSeh10yl2IXldp8BXVpsuIcBqGhZlwM67OjpqNAs/uaqidEsWFZBckgI45gg18VPjh6pJ9SFCdB8t4cPQHfmIRoDHpqkK+mVog+n0QfIBKGC0bAU2reg6sZsiN1v4Lg7LCDjulSTcDW6ylqiUPkymGlr0CUmFtzHRM0e0hjv1Xz7cuIQvKNxTpYRaqJMY1iRwRm07tUqj3KHjrXTgn54DT9gNjyI5yvE8Yc/z06C+Z4eiT2MqMbXAGNay3AEg3ZgCG8loGZ4anCMoe3mLkJtSxVgqt6rlw5OcwBUpCpiitaHJKT4lR39eqSPfrGRkXJY+1F44sgrZp7P9Dbw6wmOfuMooqEQZdqla2Cpbiz643YtH3T7C9+tiSmj42R7LZQQVmeDf2+eDexHUCZ1co29kfoiwQsPQIPkAPo+Yegp1ng64cD4WIXb+1oH8LK3TgYBvAMCvbS6UxR5XQqgMH9xgTUEiZkFsJG6UkpG7gESC/HmDTHph4ZjKE5qrrBFZcZkq/lJ77dq2SkMtPtGtm6jUgO01+8kQkm9wgH71oc1rwuzSJFKrE6xNJQtTPIUymh+1IwtiL7evVDuU6mgqUAGP6FBAgx5MAursyvyTtR9t+8WfxzNV5nNx6qF56zx+m6+wpWiUMZIhV05TIuTTLnArzN3K1XIGWDZIT45s0bdCFI+8T6UtCarK0cFR5PnptuAyqsAmvkfihh1T2Oq8vwFBsO3Fo4kDKx9spXslnZP7wq2Ee94rqsE4WvTYI65+bCmN549Dcn+N/65bTtYYeHCTe3u9gnTNfCqcfYs3iutWZTas0zUFQzkDmhDO/c6wqgRyZXTHofukHYRodedmr1VjcMW/eUNtBzZV8Pztdai7Zp2xkRBIOTOzGwmJmRhFid40D97tcuGy2FvKDw1o9m/szsxRcTrTkRH+E1JM/t+Q8mQhVNQLGJjUc7iwEHTYJDnR6aLlz2sKG9WyZjCRWPJpNtBQ4yOCXpQAfhy0LRGwH+T0w9vZ93ksouLlVlvUddriqhqop0MZlwAyzkX2g3dmLoFYjZVYfOnVZbTIzEn/nWLAeXt/wVbg6QbZ4zmFD5zBOJZfqqjF2M9OsA56X+WPeUuEj+6gM2NrFhrpD7GndCQtE78jl61r00RPX8GJQKKHSSuOy6uMB7Ayugi7GmIfYWw953bwKxP50L0FsMUYlW2MGAmWg4Ue+qGOef5do4jysXzfWCYK1OEGCHRJLu2IjXhRROH3GMh/XlXjjHOvfQGKVmMLGS08ItZGf0/e4vyQiKb/xykz1vsQ8W/Fb3YrXcYayEdU0d8Q8k8okbqkCZQbpRemXH4O8FW3oJAFFIyXwcPc/LkPmv2yznDfSG8hJHOaoDs0fHamai0fbmyn9b1Fm5HBvA+Q0dZ4xuEPVPPrZtBjOJUc+OKLb1SoGVPd9sPTtB+NBA1NR9LGjBOoIC9cKrsXCGC3UdPFGJYPbO13xNdXKHccPl4826W4ZUXQvacKP4ziDN8v4R6Vt7DxtBCu9V5abceLhXI1XyuiYToD2Vh4SNFWvlJ02xB72I0aH5SsmyAAiEfHuQDuxHhFYRDDftTCm9dezeR1lpK+hXNrhteZ8fZc9x5X2hed8UmNgsV7dieEl2SqTJsvuNOmFuAYZBW4r8s8UQ2zLr9ymyhYWbbRlGdOogcuPu0LRgICgxGRe8JFByqL7aAbd3pc+xTucudb7uIfsBN0nTE3KcpDwj3hvbbAwmLV9zu89lkp6KSpVFeaYM7jXcWOeksvQLb6SmpxjCJNrJMtWHEke24prdQ/WOUFnjGi4cQeB+0kG2kypFpJnUYkRebbKaBTniICunZDgNnixgplQVeGz27Hwa464NKbo9Hd4A+3L2AW5JOeg6kaO1RtfWG4FtE/5JgwzefyGUfVfnIPOEdxZXRhI/GxHKKsyDcymjYnSEA+pXCA7jDrEBxTxUR3CeJ0wm3cxQ4zZ0ftV4ntzXSP8gXAV3nngupU686yLWOLdyGicMdorgtTRWjFCcCy+G69z8Pylv1DBA4264X3i364Q9IdalITdJP7B/D+EPRg7fcqwoBkxpX2vilYWCHK6bxKaMhO+8P0+NNioxoKRci3w9+Cgn2ZLt8QIKfrhD9RstuwjCgZ488BNmiYZe9KgDIq6dusHTQB3n1kVbweZdiCCXOKG2hjqumn+1JRTz+/ZSufedQL6xaCylw2O6bjA0T9eEDitDv9IX4l+/xulI1rQ0nMHhDP76mVQ3FOcpkTt3OYvuHltO5GVoXSE10+vm3I+1SB");
					
				    msgWrapped.setThirdPartyCode("1");
				    
					/**************4. Invocar el servicio de SENDMESSAGE del Bus (Externo o Interno)*************/
				    
					//Se genera la petici�n Request del Bus
					Double                          time_start2 = new Double("0.0"),time_end2 = new Double("0.0");
					time_start2 = (double) System.currentTimeMillis();
					MessageWrapped msgWrappedResponse= serviceServiceagent.getPortTypeEndpoint().sendMessage(msgWrapped);
					time_end2 = (double) System.currentTimeMillis();
					

		            //Mensaje cifrada de la respuesta del Bus
					String msjRespuestaBus= msgWrappedResponse.getChiperedMessage();
					System.out.println("--> Fecha: "+new Date());
					System.out.println("--> Tiempo transcurrido en sendMessage TOTAL: "+ ( time_end2 - time_start2 )/500 +" Segundos");
					
					
					/**************5. Descifrar el response o Respuesta del BUS (Interno o Externo)*************/
					//Se genera la petici�n a Descifrar en mensaje de Respuesta pasando la misma KEY que en el Request
					//String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "0E62009B134EC807DB344ED1FE8AF328"); // QA/DEV
					String respuestaDescifrada = msgACifrar.desCifrarMensaje(msjRespuestaBus, "FC460BC243B25812B102670836BDB029");//UAT
					
					System.out.println("\n--------------------------------");
					System.out.println("*** Operaci�n Validada: ReadTransactionIsPaid ***\n");
					//System.out.println(new Date());
					System.out.println("* Respuesta cifrada:\n"+respuestaDescifrada);
					System.out.println("\n--------------------------------");
				
					
					
				  }catch (MalformedURLException e) {
						e.printStackTrace();
					}
					catch(Exception e){
						e.printStackTrace();
					}
				
			}	
	 public static String getNum(){
			char[] chars = "1234567890".toCharArray();
			StringBuilder sb = new StringBuilder();
			Random random = new Random();
			for (int i = 0; i < 6; i++) {
				char c = chars[random.nextInt(chars.length)];
				sb.append(c);
			}
			String output = sb.toString();

			return output;
		}


	 
	 
}
