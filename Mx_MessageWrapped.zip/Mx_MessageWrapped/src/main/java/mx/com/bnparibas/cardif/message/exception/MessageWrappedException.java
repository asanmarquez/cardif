package mx.com.bnparibas.cardif.message.exception;
/***********************************************************************************************
 *                                ID:MEX0151 POSNET E-LAM                                       *
 *  *********************************************************************************************
 *   Fecha: 22/02/2018                                                                          *
 *   Descripci�n:Clase que realiza el manejo de las excepciones del componente                  *
 *   @author: Floricelda Cabrera Santos                                                         *
 * **********************************************************************************************/
public class MessageWrappedException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MessageWrappedException(String msj){
		super(msj);
	}

}
